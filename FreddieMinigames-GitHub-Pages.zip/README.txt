FREDDIEMINIGAMES - GITHUB PAGES SETUP

Your website is in index.html. It contains 50 mini-games plus Chess (51 games total).

PUBLISH IT WITH GITHUB PAGES
1. Sign in to GitHub and create a new repository called freddieminigames.
2. Set the repository visibility to Public, then create the repository.
3. Choose Add file > Upload files.
4. Upload index.html from this folder and commit the changes.
5. Open the repository's Settings tab, then Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose the main branch and /(root), then Save.
8. Wait a minute or two. GitHub will show your public website address in the Pages section.

NOTES
- Game progress and scores are saved in the browser on the device being used.
- The chess AI uses an online chess library, so chess needs an internet connection.
- Worldwide live chess matchmaking is currently a preview, not a working multiplayer server.
- A shared worldwide leaderboard also needs an online database; the current leaderboard is local to the device.
